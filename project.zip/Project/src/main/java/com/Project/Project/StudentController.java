package com.Project.Project;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@CrossOrigin("http://localhost:8081")


public class StudentController {

	@Autowired
	SessionFactory factory;

	List<Student> arraylist=null;
	StudentController() {
	}


	@GetMapping("getallstudent")
	List allstudent() {
		Session s= factory.openSession();
		arraylist = s.createCriteria(Student.class).list();
		return arraylist;

	}
	@GetMapping("getstudent/{rno}")
	Student getStudent(@PathVariable int rno) {
		Session session= factory.openSession();
		Student s=session.load(Student.class, rno);
		return s;
	}



	@PostMapping("addstudent")
	public List<Student> AddStudent(@RequestBody Student student){
		{
			Session s=factory.openSession();
			Transaction tt=s.beginTransaction();
			s.save(student);
			tt.commit();
			List<Student>list=allstudent();
			return list;

		}
		}
		@PutMapping("update")
		List<Student> updateStudent(@RequestBody Student stu){
			Session s = factory.openSession();
			Transaction tt=s.beginTransaction();
			s.saveOrUpdate(stu);
			tt.commit();
			List<Student> list = allstudent();
			return list;
			
		}
		@DeleteMapping("delete/{rno}")
		 public List<Student> deleteStudent(@PathVariable int rno){
			//student is persistent object as it's contents are saved inside databases
			Session s = factory.openSession();
			Student ss= s.load(Student.class, rno);
			Transaction tt = s.beginTransaction();
			s.delete(ss);
			tt.commit();
			List<Student>list = allstudent();
			return list;
			
	}
	
}

