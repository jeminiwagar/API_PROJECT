package com.Project.Project;


import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	@RequestMapping("apicall")
	public String apicall() {
		return "apicall";
		}
	
	@RequestMapping("testcall")
	public ModelAndView test() {
	ArrayList<String> arraylist= new ArrayList<>();
	arraylist.add("Jemini");
	arraylist.add("Arbaz");
	arraylist.add("Pranav");
	 ModelAndView modelandview=new  ModelAndView("test","data",arraylist);
	 return modelandview;
	 
	}
	
	
}
